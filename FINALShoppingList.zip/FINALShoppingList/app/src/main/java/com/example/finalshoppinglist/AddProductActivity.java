package com.example.finalshoppinglist;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.Header;

public class AddProductActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        Intent intent = new Intent();
        intent.getExtras();


        final EditText et_ProductName=findViewById(R.id.et_ProductName);
        final EditText et_Description=findViewById(R.id.et_Description);
        final Button btn_AddProducts=findViewById(R.id.btn_AddProducts);

        final SharedPreferences preferences = getSharedPreferences("USER", Activity.MODE_PRIVATE);
        final String user_id=preferences.getString("id","");



        final AsyncHttpClient client= new AsyncHttpClient();

        btn_AddProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // String user=et_Userid.getText().toString();
                String productName=et_ProductName.getText().toString();
                String Desc=et_Description.getText().toString();

                if(productName.isEmpty()||Desc.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddProductActivity.this);
                    builder.setTitle("Error")
                            .setMessage("Fill All Fields")
                            .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                    builder.show();
                }
                else {
                    String url="http://dev.imagit.pl/wsg_zaliczenie/api/item/add";
                    RequestParams params = new RequestParams();
                    params.put("user",user_id);
                    //params.put("user",);
                    params.put("name",productName);
                    params.put("desc",Desc);
                    client.post(url, params, new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                            String response=new String(responseBody);
                            Toast.makeText(AddProductActivity.this,response,Toast.LENGTH_LONG).show();
                            if(response.equals("OK")){
                                Toast.makeText(AddProductActivity.this,"Succsussfully added Product",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(AddProductActivity.this,MainActivity.class);
                                startActivity(intent);
                            }

                        }

                        @Override
                        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                        }
                    });
                }

            }
        });
    }
}
