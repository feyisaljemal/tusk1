package com.example.finalshoppinglist;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ListView lv_shoppingList=findViewById(R.id.Lv_ShoppingList);
        final Button btn_Addbutton=findViewById(R.id.btn_AddButton);
        final SharedPreferences preferences = getSharedPreferences("USER", Activity.MODE_PRIVATE);
        final String user_id=preferences.getString("id","");

        final ArrayList<String>shoppingList=new ArrayList<String>();
        final ArrayAdapter<String>shoppinglistAdapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,shoppingList);
        final AsyncHttpClient client = new AsyncHttpClient();
        String url ="http://dev.imagit.pl/wsg_zaliczenie/api/items/"+user_id;
        client.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String jason = new String(responseBody);
                try {
                    JSONArray Jarry=new JSONArray(jason);
                    for (int i=0; i<Jarry.length(); i++){
                        JSONObject jObject = Jarry.getJSONObject(i);
                        String Name =jObject.getString("ITEM_NAME");
                        String Description =jObject.getString("ITEM_DESCRIPTION");
                        String item_id=jObject.getString("ITEM_ID");
                        shoppingList.add(Name+","+Description);

                    }
                    lv_shoppingList.setAdapter(shoppinglistAdapter);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });

        lv_shoppingList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,final int position, long id) {

                final AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("ERROR")
                        .setMessage("Do you want to delete this item ?")
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                String x=lv_shoppingList.getItemAtPosition(position).toString();
                                String[] a=x.split(",");
                                String item_id=a[a.length-1];

                                String url="http://dev.imagit.pl/wsg_zaliczenie/api/item/delete/"+user_id+"/"+item_id;
                                client.get(url, new AsyncHttpResponseHandler() {
                                    @Override
                                    public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                                        Toast.makeText(MainActivity.this,"item deleted",Toast.LENGTH_LONG).show();
                                        Intent intent=new Intent(MainActivity.this,MainActivity.class);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                                    }
                                });

                            }
                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                builder.show();



            }
        });



        btn_Addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,AddProductActivity.class);
                startActivity(intent);
            }
        });

    }
}
