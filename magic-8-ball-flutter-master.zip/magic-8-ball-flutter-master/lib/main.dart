import 'package:flutter/material.dart';

void main() => runApp(
      MaterialApp(
        home: null,
      ),
    );
